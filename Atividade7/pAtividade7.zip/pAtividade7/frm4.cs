﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade7
{
    public partial class frm4 : Form
    {
        public frm4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            /*  salario bruto bruto = A + Ax(0, 05xB + 0, 1xC + 0, 1xD) + Total de gratificações
                A = salário de acordo com o cargo(plano de carreira)
                B = Produção >= 100->se sim B = 1 caso contrário B = 0
                C = Produção >= 120->se sim C = 1 caso contrário C = 0
                D = Produção >= 150->se sim D = 1 caso contrário D = 0 */

            double a, prod, grat;

            if(mtxtSalario.Text == "" || mtxtProducao.Text == "" || txtNome.Text == "" || txtIncricao.Text == "" || mtxtGratificacao.Text == "" || txtCargo.Text == "")
                MessageBox.Show("Não pode campo vazio");
            else if (double.TryParse(mtxtSalario.Text, out a) &&
                    double.TryParse(mtxtProducao.Text, out prod) &&
                    double.TryParse(mtxtGratificacao.Text, out grat))
            {
                double sal, b = 0, c = 0, d = 0;

                if (prod >= 150)
                    d = 1;
                if (prod >= 120)
                    c = 1;
                if (prod >= 100)
                    b = 1;

                sal = a + a * (0.05 * b + 0.1 * c + 0.1 * d) + grat;

                if (sal > 7000)
                {
                    if (d == 1 && grat > 0)
                        txtSalBruto.Text = "R$ "+sal.ToString("N2");
                    else
                        MessageBox.Show("Restrito");
                }
                else
                    txtSalBruto.Text = "R$ "+sal.ToString("N2");
            }
            else
                MessageBox.Show("Dados Inválidos");

        }
    }
}
