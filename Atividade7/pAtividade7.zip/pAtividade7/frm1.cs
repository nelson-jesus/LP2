﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade7
{
    public partial class frm1 : Form
    {
        public frm1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rtxtTexto.Clear();
        }

        private void btnContBranco_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else if(rtxtTexto.TextLength > 100)
                MessageBox.Show("Texto maior que 100");
            else
            {                
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0;

                for (int i = 0; i < texto.Length; i++)
                {
                    if (char.IsWhiteSpace(texto[i]))
                        cont+=1;
                }
                MessageBox.Show(Convert.ToString(cont) + " espaço(s) em branco");
            }
        }

        private void btnContR_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else if (rtxtTexto.TextLength > 100)
                MessageBox.Show("Texto maior que 100");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0, i = 0;

                while(i < texto.Length)
                {
                    if (char.Equals(texto[i], 'R'))
                        cont += 1;
                    i++;
                }
                MessageBox.Show(Convert.ToString(cont) + " letra(s) 'R'");
            }
        }

        private void btnContPares_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else if (rtxtTexto.TextLength > 100)
                MessageBox.Show("Texto maior que 100");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0, i = 1;

                while (i < texto.Length)
                {
                    if (char.Equals(texto[i], texto[i-1]))
                        cont += 1;
                    i++;
                }
                MessageBox.Show(Convert.ToString(cont) + " par(es)");
            }
        }
    }
}
