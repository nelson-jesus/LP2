﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade7
{
    public partial class frm3 : Form
    {
        public frm3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if(txtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else if(txtTexto.TextLength > 50)
                MessageBox.Show("Texto muito grande");
            else
            {
                char[] texto = txtTexto.Text.ToCharArray();
                string s = "", t = txtTexto.Text.ToUpper();
                Array.Reverse(texto);

                foreach (char c in texto)
                    s = s + c.ToString();

                s = s.ToUpper();
                s = s.Replace(" ", "");

                if (s == t.Replace(" ",""))                    
                    MessageBox.Show(s + " é um palíndromo de " + txtTexto.Text);
                else
                    MessageBox.Show(s + " não é um palíndromo de " + txtTexto.Text);
            }
            txtTexto.Text = "";
        }
    }
}
