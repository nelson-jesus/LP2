﻿
namespace pAtividade7
{
    partial class frm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnContBranco = new System.Windows.Forms.Button();
            this.btnContR = new System.Windows.Forms.Button();
            this.btnContPares = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtxtTexto
            // 
            this.rtxtTexto.Location = new System.Drawing.Point(40, 57);
            this.rtxtTexto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rtxtTexto.Name = "rtxtTexto";
            this.rtxtTexto.Size = new System.Drawing.Size(508, 117);
            this.rtxtTexto.TabIndex = 0;
            this.rtxtTexto.Text = "";
            // 
            // btnContBranco
            // 
            this.btnContBranco.Location = new System.Drawing.Point(40, 228);
            this.btnContBranco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnContBranco.Name = "btnContBranco";
            this.btnContBranco.Size = new System.Drawing.Size(100, 78);
            this.btnContBranco.TabIndex = 1;
            this.btnContBranco.Text = "Nº de espaços em branco";
            this.btnContBranco.UseVisualStyleBackColor = true;
            this.btnContBranco.Click += new System.EventHandler(this.btnContBranco_Click);
            // 
            // btnContR
            // 
            this.btnContR.Location = new System.Drawing.Point(252, 228);
            this.btnContR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnContR.Name = "btnContR";
            this.btnContR.Size = new System.Drawing.Size(100, 78);
            this.btnContR.TabIndex = 2;
            this.btnContR.Text = "Contar letra \"R\"";
            this.btnContR.UseVisualStyleBackColor = true;
            this.btnContR.Click += new System.EventHandler(this.btnContR_Click);
            // 
            // btnContPares
            // 
            this.btnContPares.Location = new System.Drawing.Point(448, 228);
            this.btnContPares.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnContPares.Name = "btnContPares";
            this.btnContPares.Size = new System.Drawing.Size(100, 78);
            this.btnContPares.TabIndex = 3;
            this.btnContPares.Text = "Contar pares de letras";
            this.btnContPares.UseVisualStyleBackColor = true;
            this.btnContPares.Click += new System.EventHandler(this.btnContPares_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(252, 182);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(100, 28);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Digite um texto de até 100 characteres: ";
            // 
            // frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnContPares);
            this.Controls.Add(this.btnContR);
            this.Controls.Add(this.btnContBranco);
            this.Controls.Add(this.rtxtTexto);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frm1";
            this.Text = "frm1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtTexto;
        private System.Windows.Forms.Button btnContBranco;
        private System.Windows.Forms.Button btnContR;
        private System.Windows.Forms.Button btnContPares;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label label1;
    }
}