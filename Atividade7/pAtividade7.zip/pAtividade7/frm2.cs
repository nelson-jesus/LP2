﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividade7
{
    public partial class frm2 : Form
    {        
        public frm2()
        {
            InitializeComponent();
        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            
            if (double.TryParse(txtNumN.Text, out double n))
            {
                if (n > 0)
                {
                    double h = 0;
                    for(double i = 1; i <= n; i++)
                        h += 1/i;
                    txtNumH.Text = h.ToString("N3");
                }
                else
                    MessageBox.Show("Deve ser maior que 0");
            }
            else if(txtNumN.Text == "")
                MessageBox.Show("Não pode vazio");
            else
                MessageBox.Show("Dado Inválido");
        }
    }
}
